# R2 공개 Witness 감사 결과

- hard 판정: `FAIL`
- R2 완료 자격: `미충족`
- 공개 범위: `19`개 (`v6 13 + legacy golden 6`)
- hidden 사용: `false`
- semantic hash: `13448a876803d2d0631a549a4e6c9c451c76fc7571a6c0e0be820ef7a14ee9d0`
- Python wall-clock은 운영 진단일 뿐 witness·taxonomy·안전 판정에 사용하지 않았다.

| public id | lane | 기대 | evidence | 평가 | hard failures |
|---|---|---|---|---|---:|
| `v6_primary-00-bd4637cb3cb1` | v6_primary | local_detour_feasible | feasible, observation_undecidable | matched | 0 |
| `v6_primary-01-17bdebc564d3` | v6_primary | local_detour_feasible | feasible, observation_undecidable | matched | 0 |
| `v6_primary-02-f0c0c248641a` | v6_primary | local_detour_feasible | feasible, observation_undecidable | matched | 0 |
| `v6_primary-03-07bc7022c340` | v6_primary | local_detour_feasible | feasible, observation_undecidable | matched | 0 |
| `v6_primary-04-fd5bb7a3a6cf` | v6_primary | local_detour_feasible | feasible, observation_undecidable | matched | 0 |
| `v6_primary-05-bfea95102b6f` | v6_primary | local_detour_forbidden | forbidden, wait_only | matched | 0 |
| `v6_primary-06-4a68880f3826` | v6_primary | wait_and_resume | search_inconclusive | matched | 0 |
| `v6_primary-07-9cd5bc69fca7` | v6_primary | wait_and_resume | observation_undecidable, search_inconclusive | matched | 0 |
| `v6_primary-08-eda6c745e2f9` | v6_primary | wait_and_resume | observation_undecidable, search_inconclusive | matched | 0 |
| `v6_primary-09-42cd32adab5b` | v6_primary | dynamic_change_restop | search_inconclusive | matched | 1 |
| `v6_primary-10-ef9cbf087ce1` | v6_primary | wait_and_resume | observation_undecidable, search_inconclusive | matched | 0 |
| `v6_primary-11-ae99ac4d3958` | v6_primary | wait_and_resume | observation_undecidable, search_inconclusive | matched | 0 |
| `v6_primary-12-32770cc665f1` | v6_primary | dynamic_change_restop | observation_undecidable, search_inconclusive | matched | 0 |
| `legacy_mechanism-13-b624c37037d3` | legacy_mechanism | wait_and_resume | observation_undecidable, search_inconclusive | matched | 0 |
| `legacy_mechanism-14-d796ebd8ba71` | legacy_mechanism | local_detour_feasible | search_inconclusive | mismatched | 0 |
| `legacy_mechanism-15-a22e044380b5` | legacy_mechanism | local_detour_forbidden | forbidden, observation_undecidable, wait_only | matched | 0 |
| `legacy_mechanism-16-02264e754677` | legacy_mechanism | no_safe_solution | forbidden, no_safe_solution, observation_undecidable | matched | 0 |
| `legacy_mechanism-17-aabe71194fb4` | legacy_mechanism | observation_invalid | observation_undecidable, search_inconclusive | matched | 0 |
| `legacy_mechanism-18-28f0a990202f` | legacy_mechanism | dynamic_change_restop | observation_undecidable, search_inconclusive | not_fully_covered | 1 |

## 해석 제한

- `actual_person_and_product_safety_not_evaluated`
- `delayed_ground_truth_invalid`
- `delayed_witness_exceeds_episode`
- `evaluator_expectation_not_fully_reproduced`
- `legacy_mechanism_not_v6_primary_evidence`
- `no_ready_prediction`
- `normal_or_stress_capsule_containment_miss`
- `observation_fault_replay_is_evaluator_only_after_search`
- `observation_interrupted_during_witness`
- `offline_ground_truth_search_only`
- `online_controller_and_gate_not_evaluated`
- `online_controller_gate_and_authority_not_evaluated`
- `passing_policy_unspecified`
- `predicted_clearance_rejected`
- `python_wall_clock_is_operational_only`
- `r2_structured_templates_are_not_general_pose_space_complete`
- `simulation_only_open_loop_circular_actor`

이 결과는 동결된 합성 open-loop 원형 Actor 시뮬레이션의 연구 증거다. 제품 알고리즘 채택, 실제 사람 탑승 안전성, G1~G5 또는 경로 분석 7단계를 결정하지 않는다.
