# R7 후속 비공개 관측 시험 결과

- 판정: `FAIL`
- case: `20/20`
- Normal 완료: `4/10`
- Stress 보수적 정지: `10/10`
- hard failure: `3`
- seed commitment: `c7db071bbcc1866bbcbd8d9219a7e6ea13ff394c7e0f9235b41f7ea8733e49be`
- 범위: 새 관측 잡음·dropout 순서만, 실제 카메라·사람 안전 증거 아님

| case | profile | outcome | pass | hard |
|---|---|---|---|---:|
| `hidden-00-left-normal` | `normal` | `failed` | `False` | `1` |
| `hidden-00-left-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-00-right-normal` | `normal` | `completed` | `True` | `0` |
| `hidden-00-right-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-01-left-normal` | `normal` | `failed` | `False` | `1` |
| `hidden-01-left-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-01-right-normal` | `normal` | `completed` | `True` | `0` |
| `hidden-01-right-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-02-left-normal` | `normal` | `conservative_hold` | `False` | `0` |
| `hidden-02-left-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-02-right-normal` | `normal` | `completed` | `True` | `0` |
| `hidden-02-right-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-03-left-normal` | `normal` | `completed` | `True` | `0` |
| `hidden-03-left-stress` | `stress` | `conservative_hold` | `False` | `0` |
| `hidden-03-right-normal` | `normal` | `failed` | `False` | `1` |
| `hidden-03-right-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-04-left-normal` | `normal` | `conservative_hold` | `False` | `0` |
| `hidden-04-left-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-04-right-normal` | `normal` | `conservative_hold` | `False` | `0` |
| `hidden-04-right-stress` | `stress` | `conservative_hold` | `True` | `0` |

## 실패

- `hidden-00-left-normal:hard_failure`
- `hidden-00-left-normal:expected_outcome_failed`
- `hidden-01-left-normal:hard_failure`
- `hidden-01-left-normal:expected_outcome_failed`
- `hidden-02-left-normal:expected_outcome_failed`
- `hidden-03-left-stress:expected_outcome_failed`
- `hidden-03-right-normal:hard_failure`
- `hidden-03-right-normal:expected_outcome_failed`
- `hidden-04-left-normal:expected_outcome_failed`
- `hidden-04-right-normal:expected_outcome_failed`
- `normal_completion_count_mismatch`
- `hidden_hard_failure_nonzero`
