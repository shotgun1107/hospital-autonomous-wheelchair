# R7 C++ DWB 시간 자격 결과

- 판정: `PASS`
- Python↔C++ 동일성: `PASS`
- 안전 경계·terminal tie 동일성: `PASS`
- 시간 측정: `PASS`
- hidden: `미실행`
- 표본: `500`
- p50: `12.945ms`
- p95: `29.910ms`
- p99: `35.085ms`
- 최대: `49.961ms`
- 50ms 초과: `0/500`
- receipt: `7002afcd55d204027e962c7c0edb01a01a8fdefc3bd3dd113b4e82098b504a5f`

실제 카메라·실물·사람 안전 또는 제품 알고리즘 채택 결과가 아니다.
