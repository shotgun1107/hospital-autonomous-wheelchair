# R7 hidden-v5 관측 시험 결과

- 판정: `PASS`
- case: `20/20`
- Normal 완료: `10/10`
- Stress 조건부 안전: `10/10`
- Stress 출발 사례: `2/10`
- hard failure: `0`
- seed commitment: `1a84727b65a829f2a4492370655e255b39b386a8281f5ee14db539271bde3586`
- 범위: 새 합성 관측 순서만, 실제 카메라·사람 안전 증거 아님

| case | profile | outcome | pass | hard |
|---|---|---|---:|---:|
| `hidden-v5-00-left-normal` | `normal` | `completed` | `True` | `0` |
| `hidden-v5-00-left-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-v5-00-right-normal` | `normal` | `completed` | `True` | `0` |
| `hidden-v5-00-right-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-v5-01-left-normal` | `normal` | `completed` | `True` | `0` |
| `hidden-v5-01-left-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-v5-01-right-normal` | `normal` | `completed` | `True` | `0` |
| `hidden-v5-01-right-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-v5-02-left-normal` | `normal` | `completed` | `True` | `0` |
| `hidden-v5-02-left-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-v5-02-right-normal` | `normal` | `completed` | `True` | `0` |
| `hidden-v5-02-right-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-v5-03-left-normal` | `normal` | `completed` | `True` | `0` |
| `hidden-v5-03-left-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-v5-03-right-normal` | `normal` | `completed` | `True` | `0` |
| `hidden-v5-03-right-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-v5-04-left-normal` | `normal` | `completed` | `True` | `0` |
| `hidden-v5-04-left-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-v5-04-right-normal` | `normal` | `completed` | `True` | `0` |
| `hidden-v5-04-right-stress` | `stress` | `conservative_hold` | `True` | `0` |
