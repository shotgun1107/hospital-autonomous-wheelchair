# R7 후속 비공개 관측 시험 결과

- 판정: `FAIL`
- case: `20/20`
- Normal 완료: `9/10`
- Stress 보수적 정지: `10/10`
- hard failure: `0`
- seed commitment: `cbcb3bad9dfbd9a65fdbed4da5987f1caf14ee69c9ed94724e46698986b7dfbb`
- 범위: 새 관측 잡음·dropout 순서만, 실제 카메라·사람 안전 증거 아님

| case | profile | outcome | pass | hard |
|---|---|---|---|---:|
| `hidden-v3-00-left-normal` | `normal` | `completed` | `True` | `0` |
| `hidden-v3-00-left-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-v3-00-right-normal` | `normal` | `completed` | `True` | `0` |
| `hidden-v3-00-right-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-v3-01-left-normal` | `normal` | `completed` | `True` | `0` |
| `hidden-v3-01-left-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-v3-01-right-normal` | `normal` | `completed` | `True` | `0` |
| `hidden-v3-01-right-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-v3-02-left-normal` | `normal` | `completed` | `True` | `0` |
| `hidden-v3-02-left-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-v3-02-right-normal` | `normal` | `completed` | `True` | `0` |
| `hidden-v3-02-right-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-v3-03-left-normal` | `normal` | `completed` | `True` | `0` |
| `hidden-v3-03-left-stress` | `stress` | `conservative_hold` | `False` | `0` |
| `hidden-v3-03-right-normal` | `normal` | `completed` | `True` | `0` |
| `hidden-v3-03-right-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-v3-04-left-normal` | `normal` | `completed` | `True` | `0` |
| `hidden-v3-04-left-stress` | `stress` | `conservative_hold` | `True` | `0` |
| `hidden-v3-04-right-normal` | `normal` | `conservative_hold` | `False` | `0` |
| `hidden-v3-04-right-stress` | `stress` | `conservative_hold` | `True` | `0` |

## 실패

- `hidden-v3-03-left-stress:expected_outcome_failed`
- `hidden-v3-04-right-normal:expected_outcome_failed`
- `normal_completion_count_mismatch`
