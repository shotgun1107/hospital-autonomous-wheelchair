# R5-A persistent controller 공개 qualification

- hard 판정: `PASS`
- 공개 case: `21`
- hidden 사용: `false`
- serial/process parity: `PASS`
- repeat determinism: `PASS`
- semantic hash: `aef2ff56060762bab95198345c469f551aa05732891038e05b84c7d940e756e0`
- Python wall-clock과 worker 수는 판정 근거가 아니다.

| id | reference | RPP | DWB | controller calls | hard |
|---|---|---|---|---:|---|
| `wide-straight-left` | reference_set_ready | completed | completed | 676 | PASS |
| `wide-straight-right` | reference_set_ready | completed | completed | 673 | PASS |
| `wide-mirror-left` | reference_set_ready | completed | completed | 678 | PASS |
| `wide-mirror-right` | reference_set_ready | completed | completed | 674 | PASS |
| `narrow-corridor` | no_reference | not_called | not_called | 0 | PASS |
| `narrow-door` | no_reference | not_called | not_called | 0 | PASS |
| `just-wide-door` | no_reference | not_called | not_called | 0 | PASS |
| `dead-end` | no_reference | not_called | not_called | 0 | PASS |
| `corner-safe` | no_reference | not_called | not_called | 0 | PASS |
| `corner-rotation-blocked` | no_reference | not_called | not_called | 0 | PASS |
| `vertical-left` | reference_set_ready | completed | completed | 676 | PASS |
| `vertical-right` | reference_set_ready | completed | completed | 673 | PASS |
| `forbidden-only-block` | no_reference | not_called | not_called | 0 | PASS |
| `allowed-region-pinch` | no_reference | not_called | not_called | 0 | PASS |
| `start-unsafe` | no_reference | not_called | not_called | 0 | PASS |
| `goal-unsafe` | no_reference | not_called | not_called | 0 | PASS |
| `resource-exact` | no_reference | not_called | not_called | 0 | PASS |
| `resource-plus-one` | search_inconclusive | not_called | not_called | 0 | PASS |
| `invalid-provenance` | invalid_input | not_called | not_called | 0 | PASS |
| `crossing-static-left` | reference_set_ready | completed | completed | 1225 | PASS |
| `crossing-static-right` | reference_set_ready | completed | completed | 1213 | PASS |

## 한계

- `offline_static_reference_tracking_only`
- `spatial_only_no_actor_temporal_execution`
- `python_wall_clock_is_nonqualification`
- `no_hidden_used`
- `no_product_controller_selection`
- `no_physical_or_human_safety_claim`
